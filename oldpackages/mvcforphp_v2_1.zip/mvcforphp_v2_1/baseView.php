<?php
require_once "[mcvforphpPath]";
$view = new View();
if (true) {
    $view->render();
}
