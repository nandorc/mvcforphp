<?php
require_once "resources/scripts/mvcforphp.php";
$mvc = new MVC(0);
if (true) {
    $mvc->redir("home");
}
