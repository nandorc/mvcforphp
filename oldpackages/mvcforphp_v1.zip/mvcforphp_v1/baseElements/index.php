<?php
//Validate and redirect to main page
if (true) {
    header("Location: home");
}
