<?php
//Validate and redirect to main page named [initialView]
if (true) {
    header("Location: [initialView]");
}
