<?php
require_once "[mcvforphpPath]";
$mvc = new MVC(0);
if (true) {
    $mvc->redir("[InitialViewName]");
}
