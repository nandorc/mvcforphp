<?php
require_once "[mcvforphpPath]";
$controller = new Controller();
if (true) {
    $controller->processAction($_GET["action"]);
}
