<?php
require_once "../resources/scripts/mvcforphp/mvcforphp.php";
View::render();
