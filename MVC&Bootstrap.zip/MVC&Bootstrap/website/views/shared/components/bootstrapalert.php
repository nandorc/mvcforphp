<?php
$message = isset($data["message"]) ? $data["message"] : "";
$type = isset($data["type"]) ? $data["type"] : "info";
$title = isset($data["title"]) ? $data["title"] : "";
if ($message != "") { ?>
    <div class="alert alert-<?= $type; ?> alert-dismissible fade show" role="alert">
        <?php if ($title != "") { ?>
            <strong><?= $title; ?></strong>
        <?php } ?>
        <?= $message; ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php }
