<?php
//Variables for the Template
$title = isset($data["title"]) ? $data["title"] : "";
$errormsg = isset($data["errormsg"]) ? $data["errormsg"] : "";
$infomsg = isset($data["infomsg"]) ? $data["infomsg"] : "";
View::validateMessages($errormsg, $infomsg);
?>
<!DOCTYPE html>
<html>

<head>
    <!-- Metadata -->
    <!-- Charset -->
    <meta charset="utf-8" />
    <!-- ViewPort -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Description -->
    <meta name="description" content="" />
    <!-- KeyWords -->
    <meta name="keywords" content="" />
    <!-- Author -->
    <meta name="author" content="" />

    <!-- Page title -->
    <title><?= $title; ?></title>

    <!-- Page icon -->
    <!--<link rel="icon" href="images/icon.png" />-->

    <!-- CSS Libraries -->
    <!-- Google Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous" />
    <!-- Own library -->
    <!--<link rel="stylesheet" href="" />-->
</head>

<body>
    <main>
        <?php if ($infomsg != "") View::insertComponent("bootstrapalert", array("message" => $infomsg, "type" => "success")); ?>
        <?php if ($errormsg != "") View::insertComponent("bootstrapalert", array("message" => $errormsg, "type" => "danger", "title" => "¡Algo salió mal!")); ?>
        <?= $content(); ?>
    </main>

    <!-- JS Libraries -->
    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Popper -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <!-- Bootstrap -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <!-- Own library -->
    <!--<script src="scripts/dmt.js"></script>-->
</body>

</html>
<?php
//Template functions
