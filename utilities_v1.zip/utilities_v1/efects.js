const fade = (selector, type, time = 1) => {
    return new Promise((resolve, reject) => {
        if (type == 'in') $(selector).fadeIn(time * 1000, () => resolve())
        else if (type == 'out') $(selector).fadeOut(time * 1000, () => resolve())
        else reject('No valid type to fade')
    })
}
const slide = (selector, type, time = 1) => {
    return new Promise((resolve, reject) => {
        if (type == 'down') $(selector).slideDown(time * 1000, () => resolve())
        else if (type == "up") $(selector).slideUp(time * 1000, () => resolve())
        else if (type == 'toggle') $(selector).slideToggle(time * 1000, () => resolve())
        else reject('No valid type to slide')
    })
}