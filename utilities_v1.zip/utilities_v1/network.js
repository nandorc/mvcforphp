const sendGETRequest = request => {
    return new Promise((resolve, reject) => {
        console.log('Obteniendo datos del servidor...')
        $.get(request)
            .done(data => {
                console.log('Datos obtenidos!')
                    //console.log(data)
                resolve(JSON.parse(data))
            })
            .fail(error => reject(error.status + ': ' + error.statusText))
    })
}
const sendPOSTRequest = (request, data) => {
    return new Promise((resolve, reject) => {
        console.log('Obteniendo datos del servidor...')
        $.post(request, data)
            .done(data => {
                console.log('Datos obtenidos!')
                    //console.log(data)
                resolve(JSON.parse(data))
            })
            .fail(error => reject(error.status + ': ' + error.statusText))
    })
}