<?php
require_once "resources/scripts/mvcforphp/mvcforphp.php";
$mvc = new MVC();
$mvc->redir("base");
